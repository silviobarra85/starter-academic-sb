#!/usr/bin/env bash
set -euo pipefail

OVERLAY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${1:-.}"

if [[ ! -d "$TARGET_DIR/static" || ! -d "$TARGET_DIR/docs" || ! -f "$TARGET_DIR/netlify.toml" ]]; then
  echo "Errore: la destinazione non sembra la radice del repository." >&2
  exit 1
fi

if ! grep -Eq '"currentVersion"[[:space:]]*:[[:space:]]*"(759|760)"' "$TARGET_DIR/static/zonaorientale/assets/league-config.json"; then
  echo "Errore: V760 e incrementale rispetto a V759. Applicare prima V759 oppure usare un repository gia V759." >&2
  exit 1
fi

(
  cd "$OVERLAY_DIR"
  sha256sum -c MANIFEST_SHA256.txt
)

cp -R "$OVERLAY_DIR/static/." "$TARGET_DIR/static/"
cp -R "$OVERLAY_DIR/docs/." "$TARGET_DIR/docs/"
cp -R "$OVERLAY_DIR/netlify/." "$TARGET_DIR/netlify/"
cp "$OVERLAY_DIR/netlify.toml" "$TARGET_DIR/netlify.toml"

chmod +x "$TARGET_DIR/netlify/build-hugo-0.80.sh"
node "$TARGET_DIR/static/zonaorientale/tools/audit-static-first-v760.mjs" "$TARGET_DIR"

echo "Overlay V760 applicato e verificato in: $TARGET_DIR"
echo "Dopo il deploy esegui:"
echo "node static/zonaorientale/tools/check-live-v760.mjs https://silviobarra.com"
