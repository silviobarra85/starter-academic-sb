import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
function readMaybe(rel) {
  const full = path.join(root, rel);
  return fs.existsSync(full) ? fs.readFileSync(full, 'utf8') : '';
}
function assert(cond, msg) {
  if (!cond) throw new Error(msg);
}

const manifestPath = path.join(root, 'static/fanta-engine/data/sudatori/current/manifest.json');
const dataPath = path.join(root, 'static/fanta-engine/data/sudatori/current/sudatori-data.json');
assert(fs.existsSync(manifestPath), 'manifest Sudatori mancante');
assert(fs.existsSync(dataPath), 'dataset Sudatori mancante');

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
assert(Array.isArray(data.teams) && data.teams.length === 20, 'dataset Sudatori: attese 20 squadre');
assert(Number(manifest.players || 0) > 0, 'manifest Sudatori: conteggio giocatori non valido');

const leaguePages = [
  'static/zonaorientale/index.html',
  'static/fantapetillomantramanager/index.html'
];
for (const rel of leaguePages) {
  const html = readMaybe(rel);
  assert(html, `pagina lega mancante: ${rel}`);
  assert(!/sudatori-section-v\d+\.js/.test(html), `${rel}: sezione pubblica Sudatori JS ancora caricata`);
  assert(!/sudatori-section-v\d+\.css/.test(html), `${rel}: sezione pubblica Sudatori CSS ancora caricato`);
}

console.log('Audit Sudatori section V661 OK', JSON.stringify({
  publicSectionDisabled: true,
  dataKeptForIosudo: true,
  manifestVersion: manifest.version || null,
  players: manifest.players || null
}));
