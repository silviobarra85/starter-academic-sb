# AI Assistant Handoff V661

V661 e un overlay solo sito + workflow fix.

Stato desiderato:

- ioSudo non viene modificata.
- I dati Sudatori restano disponibili per ioSudo.
- La sezione pubblica Per i SUDATORI resta disattivata nelle home delle leghe.
- Il sito mobile usa card compatte per Listone e Rose, con colori ruolo e blocchi progressivi.
- Il flusso GitHub Action `incoming/overlays/*.zip` deve smettere di fallire per audit Sudatori obsoleti.

Nota tecnica:

Il vecchio `tools/apply-overlay-from-zip.sh` eseguiva solo:

- audit-sudatori-section-v*.mjs
- audit-iosudo-v*.mjs
- check JS Sudatori/ioSudo

Dopo la disattivazione della sezione Sudatori pubblica, l'audit storico V646 non era piu adatto. V661 introduce un audit Sudatori compatibile con lo stato attuale e aggiorna lo script per includere anche audit sito.
