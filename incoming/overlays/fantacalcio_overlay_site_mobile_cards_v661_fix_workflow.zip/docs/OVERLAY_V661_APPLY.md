# Overlay V661 - card mobile sito + fix workflow overlay

Questo overlay mantiene le modifiche V660 sulle card mobile del sito e aggiunge una correzione per il flusso automatico `incoming/overlays`.

## Perche esiste

Dopo la disattivazione della sezione pubblica `Per i SUDATORI`, il vecchio script automatico continuava a eseguire l'audit `audit-sudatori-section-v646.mjs`, non piu coerente con lo stato attuale del sito e dei dati. Questo poteva far fallire la GitHub Action durante lo step `Apply overlay zip`.

## Cosa contiene

- Card mobile ordinate e compatte per Listone e Rose, come in V660.
- Colori ruolo preservati: portieri giallo, difensori verde, centrocampisti blu, attaccanti rosso.
- Filtri mantenuti.
- Nuovo audit `audit-sudatori-section-v661.mjs`, coerente con Sudatori pubblico disattivato ma dati mantenuti per ioSudo.
- Aggiornamento di `tools/apply-overlay-from-zip.sh` per eseguire anche audit sito e controlli sintattici delle app di lega.

## Applicazione da smartphone

Caricare lo zip in:

```text
incoming/overlays/
```

La GitHub Action applichera l'overlay automaticamente.
