# AI Assistant Handoff V660

## Contesto

Dopo V659 il sito mobile usava card al posto delle tabelle pesanti per Listone e Rose, ma le card erano troppo grandi e le informazioni risultavano poco ordinate. L'utente ha chiesto di mantenere i colori dei ruoli e di adattare meglio la card allo schermo.

## Intervento

V660 e' un overlay solo sito:

- aggiunge `static/fanta-engine/css/site-performance-v660.css`;
- aggiorna i due `index.html` per usare `site-performance-v660.css?v=660`;
- aggiunge wrapper JS V660 nei due `app.js`;
- non tocca ioSudo;
- non tocca JSON, rose, listoni, manifest o service worker.

## Logica tecnica

La logica V659 resta la base: filtri, ordinamenti e pulsanti progressivi vengono preservati.
V660 ridefinisce solo il rendering mobile delle card di:

- Listone;
- Rosa/dettaglio giocatori rosa.

Ogni card riceve una classe ruolo:

- `is-role-gk` per portieri;
- `is-role-def` per difensori;
- `is-role-mid` per centrocampisti;
- `is-role-fwd` per attaccanti.

Il CSS usa `--role-rgb` per colorare bordo, badge e sfondo leggero.

## Nota per aggiornamenti futuri

Non reintrodurre render mobile con tabella completa per Listone/Rose. Su smartphone mantenere card progressive, compatte e filtrabili.
