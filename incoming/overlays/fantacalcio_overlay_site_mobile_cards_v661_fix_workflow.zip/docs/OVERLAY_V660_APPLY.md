# Overlay V660 - Card mobile sito piu compatte e colorate

## Scopo

Overlay solo sito. Non modifica ioSudo, dataset, listoni, rose JSON, PWA o sezione pubblica Per i SUDATORI.

## Modifiche

- Le card mobile di Listone e Rose mantengono il colore del ruolo:
  - portieri: giallo;
  - difensori: verde;
  - centrocampisti: blu;
  - attaccanti: rosso.
- Le informazioni sono ordinate in header + campi compatti.
- Le card sono piu piccole e responsive alla larghezza dello schermo.
- I filtri gia presenti continuano a funzionare.
- Resta il caricamento progressivo con Mostra altre voci.
- Desktop invariato: continua a usare le tabelle.

## Comandi

```bash
rm -rf ~/Downloads/fantacalcio_overlay_site_mobile_cards_v660
unzip -o ~/Downloads/fantacalcio_overlay_site_mobile_cards_v660.zip -d ~/Downloads/

cp -R ~/Downloads/fantacalcio_overlay_site_mobile_cards_v660/static/* static/
cp -R ~/Downloads/fantacalcio_overlay_site_mobile_cards_v660/docs/* docs/
```

## Controlli

```bash
node static/fanta-engine/tools/audit-site-mobile-cards-v660.mjs
node --check static/zonaorientale/assets/app.js
node --check static/fantapetillomantramanager/assets/app.js
```

## Commit

```bash
git status
git add static docs
git commit -m "Migliora card mobile sito V660"
git push origin master
```
