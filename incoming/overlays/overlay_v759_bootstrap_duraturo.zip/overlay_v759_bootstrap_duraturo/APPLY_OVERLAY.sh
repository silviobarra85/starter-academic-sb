#!/usr/bin/env bash
set -euo pipefail

OVERLAY_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${1:-.}"

if [[ ! -d "$TARGET_DIR/static" || ! -d "$TARGET_DIR/docs" ]]; then
  echo "Errore: la destinazione non sembra la radice del progetto (mancano static/ o docs/)." >&2
  exit 1
fi

cp -R "$OVERLAY_DIR/static/." "$TARGET_DIR/static/"
cp -R "$OVERLAY_DIR/docs/." "$TARGET_DIR/docs/"
cp "$OVERLAY_DIR/netlify.toml" "$TARGET_DIR/netlify.toml"

echo "Overlay V759 applicato in: $TARGET_DIR"
echo "Esegui: node static/zonaorientale/tools/audit-static-first-v759.mjs"
