# ioSudo App V719

Aggiornamento da Excel V74 del 18/07/2026.

## Interventi
- Applicati 9 alias confermati dalla lista V718: Lucca, Taremi, Aebischer, Pobega, Karlsson, Mandragora, Nzola, Pessina (solo Monza), Caprile.
- Esposito disambiguato: Cagliari = Sebastiano Esposito; Inter = Francesco Pio Esposito. Nessun alias generico `Esposito`.
- Bologna-Arminia Bielefeld aggiornata come parziale live 0-3 HT, senza tabellino giocatori.
- Nessuna nuova ufficialità club e nessun nuovo infortunato inserito.

## Conteggi
```json
{
  "version": "V719",
  "updatedAt": "2026-07-18T13:25:00+02:00",
  "teams": 20,
  "players": 777,
  "officialMoves": 362,
  "teamTransferTalks": 439,
  "transfermarktRumors": 46,
  "injuries": 24,
  "friendlies": 118,
  "friendlyMatchDetails": 1,
  "friendlyPlayerStats": 26,
  "sources": 664,
  "duplicateExactPlayers": 0,
  "duplicatePlayerIds": 0,
  "activeOfficialRumors": 0,
  "confirmedAliasesV719": 9,
  "teamSpecificAliasesV719": 1,
  "espositoDisambiguationsV719": 3,
  "duplicateCandidatesV719": 10,
  "sourcesAddedV719": 3,
  "friendliesPatchedV719": 1,
  "officialTalksClosedV719": 0
}
```
